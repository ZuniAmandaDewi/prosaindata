#!/bin/bash

# Install any dependencies you have in this shell script,
# see https://docs.orchest.io/en/latest/fundamentals/environments.html#install-packages

# E.g. mamba install -y tensorflow
pip install psycopg2-binary
pip install pandas
pip install mysql-connector
pip install pymssql
pip install numpy
pip install scikit-learn
pip install matplotlib